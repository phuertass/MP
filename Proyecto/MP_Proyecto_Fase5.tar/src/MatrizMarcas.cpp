/***************************************************************************/
/***************************************************************************/
// METODOLOGIA DE LA PROGRAMACION
//
// Proyecto Gestion de marcas de atletismo
//
// Implementacion del tipo "MatrizMarcas"y de las funciones de gesti�n.
//
// Cabecera del fichero: MatrizMarcas.h
//  
// Fichero: MatrizMarcas.cpp
//
/***************************************************************************/
/***************************************************************************/
#include <iostream>
#include <iomanip>
#include <cstring>
#include <string>
#include <cstdlib>

#include "MatrizMarcas.h"

using namespace std; 

//Constructor
MatrizMarcas::MatrizMarcas(int n){
    num_pruebas = n;
    utilizados = 0;
    ReservaMemoria(num_pruebas);
}


//Destructor
MatrizMarcas::~MatrizMarcas(){
    LiberaMatrizMarcas();
}

//Constructor de copia
MatrizMarcas::MatrizMarcas(const MatrizMarcas & m)
{
    num_pruebas = m.num_pruebas;
    utilizados = m.utilizados;
    ReservaMemoria(num_pruebas);
    for(int i=0; i<utilizados; i++)
        pruebas[i] = m.pruebas[i];
}

// Sobrecarga del operador asignacion
MatrizMarcas & MatrizMarcas::operator=(const MatrizMarcas & m)
{
    if(this != &m)
    {
        num_pruebas = m.num_pruebas;
        utilizados = m.utilizados;
        ReservaMemoria(num_pruebas);
        for(int i=0; i<utilizados; i++)
            pruebas[i] = m.pruebas[i];
    }
    return *this;
}


//Añade un vector marcas al final de pruebas
void MatrizMarcas :: AniadeVectorMarcas(const VectorMarcas v){
    pruebas[utilizados] = v;
    utilizados++;
}

//Devuelve el vector marcas en la posicion i
VectorMarcas & MatrizMarcas::Marcas(int i){
    return pruebas[i];
}

VectorMarcas MatrizMarcas::operator()(int i){
    return pruebas[i-1];
}

VectorMarcas MatrizMarcas::operator[](int i){
    return pruebas[i-1];
}

//Getters y setters
int MatrizMarcas::getNumPruebas() const{
    return num_pruebas;
}

void MatrizMarcas::setNumPruebas(int n){
    num_pruebas = n;
}

//Funciones de ordenacion
void MatrizMarcas::OrdenarPorTiempos(){
    for(int i=0; i<num_pruebas; i++){
        pruebas[i].OrdenarPorTiempos();
    }
}

void MatrizMarcas::OrdenarPorNombre(){
    for(int i=0; i<num_pruebas; i++){
        pruebas[i].OrdenarPorNombre();
    }
}

void MatrizMarcas::OrdenarPorFecha(){
    for(int i=0; i<num_pruebas; i++){
        pruebas[i].OrdenarPorFecha();
    }
}

//Private
void MatrizMarcas::LiberaMatrizMarcas(){
    if (pruebas){
        delete [] pruebas;
        pruebas = NULL;
        num_pruebas = 0;
    }
}

void MatrizMarcas::ReservaMemoria(int n){
    pruebas = new VectorMarcas[n];
}