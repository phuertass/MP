/***************************************************************************/
/***************************************************************************/
// METODOLOGIA DE LA PROGRAMACION
//
// Proyecto Gestion de marcas de atletismo
//
// Declaraci�n del tipo "MatrizMarcas"y de las funciones de gesti�n.
// Implementaciones en MatrizMarcas.cpp
//
//  
// Fichero: MatrizMarcas.h
//
/***************************************************************************/
/***************************************************************************/
#ifndef MATRIZMARCAS_H
#define MATRIZMARCAS_H

#include "ClasesRankingMarcas.h"
#include "VectorMarcas.h"
#include <string>
using namespace std;

class MatrizMarcas{
    private :
        
        int num_pruebas;
        int utilizados;
        VectorMarcas * pruebas;

    public :

        //Constructores
        MatrizMarcas();
        MatrizMarcas(int n);

        //Constructor de copia
        MatrizMarcas(const MatrizMarcas & m);

        //Sobrecarga del operador asignacion
        MatrizMarcas & operator=(const MatrizMarcas & m);

        //Destructor
        ~MatrizMarcas();

        //Añade un vector marcas al final de pruebas
        void AniadeVectorMarcas(VectorMarcas v);

        //Devuelve el vector marcas en la posicion i
        VectorMarcas & Marcas(int i);
        VectorMarcas operator()(int i);
        VectorMarcas operator[](int i);

        //Funciones de ordenacion
        void OrdenarPorTiempos();
        void OrdenarPorNombre();
        void OrdenarPorFecha();

        //Getters y setters
        int getNumPruebas() const;
        void setNumPruebas(int n);
   

    //Metodos privados
    private:
        //Libera la memoria de la matriz
        void LiberaMatrizMarcas();

        //Reserva memoria para la matriz
        void ReservaMemoria(int n);

};

#endif